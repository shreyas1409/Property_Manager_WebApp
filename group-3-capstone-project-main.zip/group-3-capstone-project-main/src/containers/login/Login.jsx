import React from "react";

const Login = () => {
  return (
    <>
      {" "}
      <button>Hello!</button>
    </>
  );
};

export default Login;
