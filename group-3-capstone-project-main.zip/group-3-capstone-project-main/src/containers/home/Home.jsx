import React from "react";

const Home = () => {
  return (
    <div className="fixed w-full h-full ">
      <div className="flex bg-cover bg-homepageBg h-full w-full "></div>
    </div>
  );
};

export default Home;
