export { default as AboutPage } from "./about/About";
export { default as ContactPage } from "./contact/Contact";
export { default as HomePage } from "./home/Home";
export { default as LoginPage } from "./login/Login";
export { default as PropertyPage } from "./property/Property";
export { default as SignupPage } from "./signup/Signup";
