import React from "react";

const Property = () => {
  return <div>Property</div>;
};

export default Property;
